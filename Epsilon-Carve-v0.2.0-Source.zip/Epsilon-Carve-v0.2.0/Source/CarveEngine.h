#pragma once

#include <array>
#include <atomic>
#include <cstddef>

namespace carve
{
constexpr std::size_t bandCount = 16;
constexpr std::size_t maxChannels = 2;
constexpr float lowestBandHz = 60.0f;
constexpr float highestBandHz = 14000.0f;
constexpr float maximumCarveWeight = 0.175f;

float bandCentreHz(std::size_t index) noexcept;

enum class TriggerSource
{
    external,
    self,
    unavailable
};

struct Settings
{
    float amountPercent;
    float sensitivityDb;
    float attackMs;
    float releaseMs;
    float mixPercent;
    float lowCutHz;
    float highCutHz;
    bool external;
};

struct BandReading
{
    float triggerPeak = 0.0f;
    float targetPeak = 0.0f;
    float carveWeight = 0.0f;
};

struct MeterFrame
{
    std::array<BandReading, bandCount> bands {};
    float triggerInputPeak = 0.0f;
    float lowCutHz = 40.0f;
    float highCutHz = 16000.0f;
    float filterCeilingHz = highestBandHz;
    TriggerSource source = TriggerSource::self;
};

class Engine
{
public:
    using TargetChannels = std::array<float*, maxChannels>;
    using TriggerChannels = std::array<const float*, maxChannels>;

    void prepare(double sampleRateHz) noexcept;
    void process(const TargetChannels& target, int numTargetChannels,
                 const TriggerChannels& sidechain, int numSidechainChannels,
                 int samples, const Settings& settings) noexcept;

    // The editor is the only consumer. Audio can continue while it reads or closes.
    void setMeteringEnabled(bool enabled) noexcept;
    bool readMeterFrame(MeterFrame& frame) noexcept;

private:
    struct Filter
    {
        float lp = 0.0f;
        float bp = 0.0f;

        float process(float input, float coefficient) noexcept;
    };

    struct Band
    {
        Filter target;
        Filter trigger;
        float envelope = 0.0f;
        float reduction = 0.0f;
    };

    template <bool Metering>
    void processSamples(const TargetChannels& target, const TriggerChannels& trigger,
                        int channels, int samples, const Settings& settings,
                        TriggerSource source) noexcept;
    void publishMeterFrame(const Settings& settings) noexcept;

    std::array<std::array<Band, bandCount>, maxChannels> bands {};
    std::array<float, bandCount> nominalCentres {};
    std::array<float, bandCount> coefficients {};
    float sampleRate = 44100.0f;
    float filterCeiling = sampleRate * 0.12f;

    MeterFrame window;
    int samplesInWindow = 0;
    int samplesPerFrame = 1470;
    std::atomic<bool> meteringEnabled { false };

    // Three fixed slots. The producer and consumer each own one slot and exchange
    // it with the middle slot. The ready bit marks an unread producer publication.
    static constexpr unsigned indexMask = 3;
    static constexpr unsigned readyBit = 4;
    static_assert(std::atomic<unsigned>::is_always_lock_free);
    static_assert(std::atomic<bool>::is_always_lock_free);
    std::array<MeterFrame, 3> meterSlots {};
    unsigned writeIndex = 0;
    unsigned readIndex = 2;
    std::atomic<unsigned> middle { 1 };
};
}
