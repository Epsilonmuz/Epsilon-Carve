#include "PluginEditor.h"

namespace
{
const juce::Colour background { 0xff0e1621 };
const juce::Colour panel { 0xff182534 };
const juce::Colour plotBackground { 0xff101a27 };
const juce::Colour textColour { 0xffedf5ff };
const juce::Colour muted { 0xff9eb0c3 };
const juce::Colour triggerColour { 0xffffc277 };
const juce::Colour targetColour { 0xffb9cfee };
const juce::Colour carveColour { 0xff40caff };
constexpr float floorDb = -80.0f;
constexpr float cutScale = 0.20f;

juce::Font font(float height, bool bold = false)
{
    return juce::Font(juce::FontOptions(height, bold ? juce::Font::bold : juce::Font::plain));
}

juce::String frequencyText(float frequency)
{
    return frequency < 1000.0f ? juce::String(frequency, 0) + " Hz"
                               : juce::String(frequency / 1000.0f, 2) + " kHz";
}

struct PlotBounds
{
    juce::Rectangle<float> levels;
    juce::Rectangle<float> cuts;

    float bandWidth() const { return levels.getWidth() / static_cast<float>(carve::bandCount); }

    float bandX(std::size_t index) const
    {
        return levels.getX() + (static_cast<float>(index) + 0.5f) * bandWidth();
    }
};
}

class CarveBandDisplay final : public juce::Component, private juce::Timer
{
public:
    explicit CarveBandDisplay(EpsilonCarveAudioProcessor& processorToUse)
        : processor(processorToUse)
    {
        setTitle("Live sidechain, target and carve bands");
        processor.readMeterFrame(frame);
        processor.setMeteringEnabled(true);
        startTimerHz(30);
    }

    ~CarveBandDisplay() override
    {
        stopTimer();
        processor.setMeteringEnabled(false);
    }

    void paint(juce::Graphics& g) override
    {
        const auto bounds = getLocalBounds().toFloat();
        g.setColour(panel);
        g.fillRoundedRectangle(bounds, 12.0f);
        if (getWidth() < 160 || getHeight() < 185)
            return;

        const auto plot = plotBounds();
        paintHeader(g);
        paintGrid(g, plot);

        if (hasFrame)
        {
            paintCuts(g, plot);
            paintTrace(g, plot, &carve::BandReading::targetPeak, targetColour);
            paintTrace(g, plot, &carve::BandReading::triggerPeak, triggerColour);
        }
        paintFooter(g);
    }

    void mouseMove(const juce::MouseEvent& event) override
    {
        const auto plot = plotBounds();
        int next = -1;
        if (plot.levels.getUnion(plot.cuts).contains(event.position))
            next = static_cast<int>((event.position.x - plot.levels.getX()) / plot.bandWidth());

        if (next != hoveredBand)
        {
            hoveredBand = next;
            repaint();
        }
    }

    void mouseExit(const juce::MouseEvent&) override
    {
        hoveredBand = -1;
        repaint();
    }

private:
    PlotBounds plotBounds() const
    {
        const auto width = static_cast<float>(getWidth()) - 76.0f;
        const auto height = static_cast<float>(getHeight());
        constexpr float cutHeight = 63.0f;
        const auto cutTop = height - 56.0f - cutHeight;
        return { { 56.0f, 58.0f, width, cutTop - 71.0f },
                 { 56.0f, cutTop, width, cutHeight } };
    }

    void timerCallback() override
    {
        const auto now = juce::Time::getMillisecondCounter();
        if (processor.readMeterFrame(frame))
        {
            hasFrame = true;
            lastFrameMs = now;
            repaint();
        }
        else if (hasFrame && now - lastFrameMs > 250)
        {
            hasFrame = false;
            repaint();
        }
    }

    juce::String sourceStatus() const
    {
        if (!hasFrame)
            return "WAITING FOR AUDIO";
        if (frame.source == carve::TriggerSource::self)
            return "SELF DETECTION";
        if (frame.source == carve::TriggerSource::unavailable)
            return "EXT INPUT DISABLED  /  SELF";
        return frame.triggerInputPeak >= 0.0001f ? "EXT  /  SIGNAL" : "EXT  /  QUIET";
    }

    void paintHeader(juce::Graphics& g) const
    {
        g.setColour(textColour);
        g.setFont(font(16.0f, true));
        g.drawText("LIVE BAND MONITOR", 16, 9, 220, 22, juce::Justification::centredLeft);

        const auto badge = juce::Rectangle<float>(static_cast<float>(getWidth()) - 239.0f,
                                                  10.0f, 220.0f, 21.0f);
        g.setColour(plotBackground);
        g.fillRoundedRectangle(badge, 4.0f);
        g.setColour(hasFrame && frame.source == carve::TriggerSource::external
                             && frame.triggerInputPeak >= 0.0001f ? triggerColour : muted);
        g.setFont(font(11.0f, true));
        g.drawFittedText(sourceStatus(), badge.toNearestInt(), juce::Justification::centred, 1);

        const auto legend = [&g](int x, juce::Colour colour, const char* label, int width)
        {
            g.setColour(colour);
            g.fillEllipse(static_cast<float>(x), 38.0f, 7.0f, 7.0f);
            g.drawText(label, x + 11, 33, width, 17, juce::Justification::centredLeft);
        };
        legend(16, triggerColour, "TRIGGER INPUT", 106);
        legend(145, targetColour, "TARGET INPUT", 102);
        legend(271, carveColour, "CARVE WEIGHT", 110);
    }

    void paintGrid(juce::Graphics& g, const PlotBounds& plot) const
    {
        g.setColour(plotBackground);
        g.fillRect(plot.levels);
        g.fillRect(plot.cuts);

        if (hasFrame)
        {
            g.setColour(juce::Colours::black.withAlpha(0.30f));
            for (std::size_t band = 0; band < carve::bandCount; ++band)
            {
                const auto frequency = carve::bandCentreHz(band);
                if (frequency < frame.lowCutHz || frequency > frame.highCutHz)
                {
                    const auto x = plot.bandX(band) - plot.bandWidth() * 0.5f;
                    g.fillRect(plot.cuts.withX(x).withWidth(plot.bandWidth()));
                }
            }
        }

        if (hoveredBand >= 0 && hoveredBand < static_cast<int>(carve::bandCount))
        {
            const auto x = plot.bandX(static_cast<std::size_t>(hoveredBand)) - plot.bandWidth() * 0.5f;
            g.setColour(juce::Colours::white.withAlpha(0.075f));
            g.fillRect(plot.levels.withX(x).withWidth(plot.bandWidth()));
            g.fillRect(plot.cuts.withX(x).withWidth(plot.bandWidth()));
        }

        g.setFont(font(10.5f));
        const auto horizontal = [&g, &plot](float y, const juce::String& label)
        {
            g.setColour(muted.withAlpha(0.24f));
            g.drawHorizontalLine(juce::roundToInt(y), plot.levels.getX(), plot.levels.getRight());
            g.setColour(muted);
            g.drawText(label, 7, juce::roundToInt(y) - 7, 43, 14, juce::Justification::centredRight);
        };

        for (int db = 0; db >= static_cast<int>(floorDb); db -= 20)
        {
            const auto fraction = static_cast<float>(db) / floorDb;
            horizontal(plot.levels.getY() + fraction * plot.levels.getHeight(),
                       db == 0 ? juce::String("0 dBFS") : juce::String(db));
        }
        horizontal(plot.cuts.getY(), "20%");
        horizontal(plot.cuts.getCentreY(), "10%");
        horizontal(plot.cuts.getBottom(), "0%");

        for (std::size_t band = 0; band < carve::bandCount; ++band)
        {
            const auto x = juce::roundToInt(plot.bandX(band));
            g.setColour(muted.withAlpha(0.12f));
            g.drawVerticalLine(x, plot.levels.getY(), plot.levels.getBottom());
            g.drawVerticalLine(x, plot.cuts.getY(), plot.cuts.getBottom());

            if (band % 3 == 0)
            {
                g.setColour(muted);
                g.drawText(frequencyText(carve::bandCentreHz(band)), x - 33,
                           juce::roundToInt(plot.cuts.getBottom()) + 4, 66, 16,
                           juce::Justification::centred);
            }
        }
    }

    void paintTrace(juce::Graphics& g, const PlotBounds& plot,
                    float carve::BandReading::* field, juce::Colour colour) const
    {
        juce::Path trace;
        for (std::size_t band = 0; band < carve::bandCount; ++band)
        {
            const auto db = juce::Decibels::gainToDecibels(frame.bands[band].*field, floorDb);
            const auto fraction = juce::jlimit(0.0f, 1.0f, db / floorDb);
            const auto x = plot.bandX(band);
            const auto y = plot.levels.getY() + fraction * plot.levels.getHeight();
            if (band == 0)
                trace.startNewSubPath(x, y);
            else
                trace.lineTo(x, y);
        }
        g.setColour(colour);
        g.strokePath(trace, juce::PathStrokeType(1.8f));
    }

    void paintCuts(juce::Graphics& g, const PlotBounds& plot) const
    {
        g.setColour(carveColour);
        const auto width = plot.bandWidth() * 0.66f;
        for (std::size_t band = 0; band < carve::bandCount; ++band)
        {
            const auto fraction = juce::jlimit(0.0f, 1.0f, frame.bands[band].carveWeight / cutScale);
            const auto height = fraction * plot.cuts.getHeight();
            g.fillRect(plot.bandX(band) - width * 0.5f, plot.cuts.getBottom() - height, width, height);
        }
    }

    void paintFooter(juce::Graphics& g) const
    {
        juce::String message = "Hover a band to compare its readings. Carve shows the DSP weight.";
        if (hasFrame)
        {
            if (hoveredBand >= 0 && hoveredBand < static_cast<int>(carve::bandCount))
            {
                const auto index = static_cast<std::size_t>(hoveredBand);
                const auto nominal = carve::bandCentreHz(index);
                const auto& reading = frame.bands[index];
                message = frequencyText(nominal);
                if (nominal > frame.filterCeilingHz)
                    message += " (" + frequencyText(frame.filterCeilingHz) + " filter)";
                message += "   |   Trigger " + peakText(reading.triggerPeak);
                message += "   |   Target " + peakText(reading.targetPeak);
                message += "   |   Carve " + juce::String(reading.carveWeight * 100.0f, 1) + "%";
            }
            else if (frame.filterCeilingHz < carve::highestBandHz)
            {
                message = "Hover for band readings. Upper filters share a ceiling at "
                        + frequencyText(frame.filterCeilingHz) + ".";
            }
        }
        g.setColour(muted);
        g.setFont(font(11.5f));
        g.drawFittedText(message, 16, getHeight() - 29, getWidth() - 32, 19,
                         juce::Justification::centredLeft, 1);
    }

    static juce::String peakText(float gain)
    {
        const auto db = juce::Decibels::gainToDecibels(gain, floorDb);
        return db <= floorDb ? juce::String("<= -80 dBFS") : juce::String(db, 1) + " dBFS";
    }

    EpsilonCarveAudioProcessor& processor;
    carve::MeterFrame frame;
    bool hasFrame = false;
    juce::uint32 lastFrameMs = 0;
    int hoveredBand = -1;
};

EpsilonCarveAudioProcessorEditor::EpsilonCarveAudioProcessorEditor(EpsilonCarveAudioProcessor& processor)
    : AudioProcessorEditor(&processor), display(std::make_unique<CarveBandDisplay>(processor))
{
    constexpr std::array<const char*, 7> ids { "amount", "sensitivity", "attack", "release", "mix", "low", "high" };
    constexpr std::array<const char*, 7> names { "AMOUNT", "SENSITIVITY", "ATTACK", "RELEASE", "MIX", "LOW CUT", "HIGH CUT" };
    constexpr std::array<const char*, 7> units { "%", " dB", " ms", " ms", "%", " Hz", " Hz" };

    addAndMakeVisible(*display);
    for (std::size_t index = 0; index < knobs.size(); ++index)
    {
        auto& knob = knobs[index];
        knob.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        knob.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 87, 19);
        knob.setTextValueSuffix(units[index]);
        knob.setScrollWheelEnabled(false);
        knob.setColour(juce::Slider::rotarySliderFillColourId, carveColour);
        knob.setColour(juce::Slider::rotarySliderOutlineColourId, panel.brighter(0.32f));
        knob.setColour(juce::Slider::thumbColourId, textColour);
        knob.setColour(juce::Slider::textBoxTextColourId, textColour);
        knob.setColour(juce::Slider::textBoxOutlineColourId, panel.brighter(0.18f));
        knob.setTitle(names[index]);
        addAndMakeVisible(knob);

        auto& label = labels[index];
        label.setText(names[index], juce::dontSendNotification);
        label.setFont(font(11.0f, true));
        label.setJustificationType(juce::Justification::centred);
        label.setColour(juce::Label::textColourId, muted);
        addAndMakeVisible(label);
        attachments[index] = std::make_unique<Attachment>(processor.params, ids[index], knob);
    }

    external.setColour(juce::ToggleButton::textColourId, textColour);
    external.setColour(juce::ToggleButton::tickColourId, carveColour);
    addAndMakeVisible(external);
    externalAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        processor.params, "external", external);

    setResizable(true, true);
    setResizeLimits(770, 550, 1280, 850);
    setSize(900, 612);
}

EpsilonCarveAudioProcessorEditor::~EpsilonCarveAudioProcessorEditor() = default;

void EpsilonCarveAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(background);
    g.setColour(carveColour);
    g.setFont(font(26.0f, true));
    g.drawText("EPSILON CARVE", 22, 12, getWidth() - 160, 30, juce::Justification::centredLeft);
    g.setColour(muted);
    g.setFont(font(13.0f));
    g.drawText("Frequency-aware sidechain ducking", 23, 44, 345, 18, juce::Justification::centredLeft);
    g.drawText("V0.2.0", getWidth() - 112, 18, 90, 22, juce::Justification::centredRight);
}

void EpsilonCarveAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced(22, 12);
    area.removeFromTop(62);
    auto controls = area.removeFromBottom(132);
    display->setBounds(area.withTrimmedBottom(12));

    auto switches = controls.removeFromBottom(26);
    external.setBounds(switches.removeFromLeft(215));
    const auto cellWidth = controls.getWidth() / static_cast<int>(knobs.size());
    for (std::size_t index = 0; index < knobs.size(); ++index)
    {
        auto cell = controls.removeFromLeft(cellWidth).reduced(4, 0);
        labels[index].setBounds(cell.removeFromBottom(18));
        knobs[index].setBounds(cell);
    }
}
