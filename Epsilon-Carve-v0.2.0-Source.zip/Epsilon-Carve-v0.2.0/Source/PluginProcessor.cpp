#include "PluginProcessor.h"
#include "PluginEditor.h"

juce::AudioProcessorValueTreeState::ParameterLayout EpsilonCarveAudioProcessor::makeLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    auto add = [&layout](const char* id, const char* name, float low, float high, float initial)
    {
        layout.add(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { id, 1 }, name, juce::NormalisableRange<float> { low, high }, initial));
    };

    add("amount",      "Amount",         0.0f,   100.0f,    40.0f);
    add("sensitivity", "Sensitivity",  -48.0f,    24.0f,     0.0f);
    add("attack",      "Attack ms",      1.0f,   150.0f,    15.0f);
    add("release",     "Release ms",    10.0f,  1000.0f,   180.0f);
    add("mix",         "Mix",            0.0f,   100.0f,   100.0f);
    add("low",         "Low cutoff Hz", 30.0f,  1000.0f,    40.0f);
    add("high",        "High cutoff Hz", 1000.0f, 20000.0f, 16000.0f);

    layout.add(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { "external", 1 }, "External sidechain", true));
    return layout;
}

EpsilonCarveAudioProcessor::EpsilonCarveAudioProcessor()
    : AudioProcessor(BusesProperties()
          .withInput("Input", juce::AudioChannelSet::stereo(), true)
          .withOutput("Output", juce::AudioChannelSet::stereo(), true)
          .withInput("Sidechain", juce::AudioChannelSet::stereo(), false)),
      params(*this, nullptr, "PARAMETERS", makeLayout())
{
}

bool EpsilonCarveAudioProcessor::isBusesLayoutSupported(const BusesLayout& layout) const
{
    const auto main = layout.getMainInputChannelSet();
    if ((main != juce::AudioChannelSet::mono() && main != juce::AudioChannelSet::stereo())
        || layout.getMainOutputChannelSet() != main)
        return false;

    if (layout.inputBuses.size() < 2)
        return true;

    const auto side = layout.getChannelSet(true, 1);
    return side.isDisabled() || side == juce::AudioChannelSet::mono()
                            || side == juce::AudioChannelSet::stereo();
}

void EpsilonCarveAudioProcessor::prepareToPlay(double sampleRate, int)
{
    engine.prepare(sampleRate);
}

void EpsilonCarveAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    if (buffer.getNumSamples() == 0)
        return;

    auto value = [this](const char* id)
    {
        return params.getRawParameterValue(id)->load(std::memory_order_relaxed);
    };

    const carve::Settings settings { value("amount"), value("sensitivity"), value("attack"),
                                    value("release"), value("mix"), value("low"), value("high"),
                                    value("external") > 0.5f };

    auto main = getBusBuffer(buffer, false, 0);
    const auto mainChannels = juce::jmin(main.getNumChannels(), static_cast<int>(carve::maxChannels));
    carve::Engine::TargetChannels target {};
    for (int channel = 0; channel < mainChannels; ++channel)
        target[channel] = main.getWritePointer(channel);

    carve::Engine::TriggerChannels trigger {};
    const auto sidechainChannels = settings.external
        ? juce::jmin(getChannelCountOfBus(true, 1), static_cast<int>(carve::maxChannels))
        : 0;
    if (sidechainChannels > 0)
    {
        auto sidechain = getBusBuffer(buffer, true, 1);
        for (int channel = 0; channel < sidechainChannels; ++channel)
            trigger[channel] = sidechain.getReadPointer(channel);
    }

    engine.process(target, mainChannels, trigger, sidechainChannels, buffer.getNumSamples(), settings);
}

juce::AudioProcessorEditor* EpsilonCarveAudioProcessor::createEditor()
{
    return new EpsilonCarveAudioProcessorEditor(*this);
}

void EpsilonCarveAudioProcessor::getStateInformation(juce::MemoryBlock& destination)
{
    auto state = params.copyState();
    if (auto xml = state.createXml())
        copyXmlToBinary(*xml, destination);
}

void EpsilonCarveAudioProcessor::setStateInformation(const void* data, int size)
{
    if (auto xml = getXmlFromBinary(data, size))
        if (xml->hasTagName(params.state.getType()))
            params.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new EpsilonCarveAudioProcessor();
}
