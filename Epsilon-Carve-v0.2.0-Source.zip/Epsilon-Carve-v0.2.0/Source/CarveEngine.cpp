#include "CarveEngine.h"

#include <algorithm>
#include <cmath>

namespace carve
{
namespace
{
constexpr float pi = 3.14159265358979323846f;
constexpr float damping = 1.0f / 1.4f;
constexpr float bandContribution = 0.25f;
constexpr float maximumReduction = maximumCarveWeight / bandContribution;
constexpr float meterFramesPerSecond = 30.0f;
}

float bandCentreHz(std::size_t index) noexcept
{
    return lowestBandHz * std::pow(2.0f, static_cast<float>(index)
                                      * std::log2(highestBandHz / lowestBandHz)
                                      / static_cast<float>(bandCount - 1));
}

float Engine::Filter::process(float input, float coefficient) noexcept
{
    lp += coefficient * bp;
    const auto high = input - lp - damping * bp;
    bp += coefficient * high;
    return bp;
}

void Engine::prepare(double sampleRateHz) noexcept
{
    sampleRate = std::isfinite(sampleRateHz) && sampleRateHz > 0.0
                   ? static_cast<float>(sampleRateHz)
                   : 44100.0f;
    filterCeiling = sampleRate * 0.12f;
    samplesPerFrame = std::max(1, static_cast<int>(std::lround(sampleRate / meterFramesPerSecond)));
    bands = {};
    window = {};
    samplesInWindow = 0;

    for (std::size_t band = 0; band < bandCount; ++band)
    {
        nominalCentres[band] = bandCentreHz(band);
        const auto centre = std::min(nominalCentres[band], filterCeiling);
        coefficients[band] = 2.0f * std::sin(pi * centre / sampleRate);
    }
}

void Engine::process(const TargetChannels& target, int numTargetChannels,
                     const TriggerChannels& sidechain, int numSidechainChannels,
                     int samples, const Settings& settings) noexcept
{
    if (numTargetChannels == 0 || samples == 0)
        return;

    TriggerChannels trigger { target[0], target[1] };
    auto source = TriggerSource::self;
    if (settings.external)
    {
        source = TriggerSource::unavailable;
        if (numSidechainChannels > 0)
        {
            source = TriggerSource::external;
            for (int channel = 0; channel < numTargetChannels; ++channel)
                trigger[channel] = sidechain[std::min(channel, numSidechainChannels - 1)];
        }
    }

    if (meteringEnabled.load(std::memory_order_relaxed))
    {
        if (window.source != source)
        {
            window = {};
            samplesInWindow = 0;
            window.source = source;
        }
        processSamples<true>(target, trigger, numTargetChannels, samples, settings, source);
    }
    else
    {
        if (samplesInWindow != 0)
        {
            window = {};
            samplesInWindow = 0;
        }
        processSamples<false>(target, trigger, numTargetChannels, samples, settings, source);
    }
}

template <bool Metering>
void Engine::processSamples(const TargetChannels& target, const TriggerChannels& trigger,
                            int channels, int samples, const Settings& settings,
                            TriggerSource source) noexcept
{
    const auto amount = settings.amountPercent / 100.0f;
    const auto sensitivity = std::pow(10.0f, settings.sensitivityDb / 20.0f);
    const auto mix = settings.mixPercent / 100.0f;
    const auto attack = std::exp(-1.0f / (std::max(1.0f, settings.attackMs) * 0.001f * sampleRate));
    const auto release = std::exp(-1.0f / (std::max(1.0f, settings.releaseMs) * 0.001f * sampleRate));

    std::array<bool, bandCount> inRange {};
    for (std::size_t band = 0; band < bandCount; ++band)
        inRange[band] = nominalCentres[band] >= settings.lowCutHz
                       && nominalCentres[band] <= settings.highCutHz;

    for (int sample = 0; sample < samples; ++sample)
    {
        for (int channel = 0; channel < channels; ++channel)
        {
            const auto input = target[channel][sample];
            const auto key = trigger[channel][sample];
            float delta = 0.0f;

            if constexpr (Metering)
                window.triggerInputPeak = std::max(window.triggerInputPeak, std::abs(key));

            for (std::size_t band = 0; band < bandCount; ++band)
            {
                auto& state = bands[channel][band];
                const auto triggerBand = state.trigger.process(key, coefficients[band]);
                const auto targetBand = state.target.process(input, coefficients[band]);
                const auto triggerMagnitude = std::abs(triggerBand);
                const auto level = triggerMagnitude * sensitivity;
                const auto smoothing = level > state.envelope ? attack : release;
                state.envelope = smoothing * state.envelope + (1.0f - smoothing) * level;

                const auto desired = inRange[band]
                                   ? amount * std::clamp(state.envelope * 3.0f, 0.0f, maximumReduction)
                                   : 0.0f;
                state.reduction = 0.995f * state.reduction + 0.005f * desired;
                delta += targetBand * state.reduction * bandContribution;

                if constexpr (Metering)
                {
                    auto& reading = window.bands[band];
                    reading.triggerPeak = std::max(reading.triggerPeak, triggerMagnitude);
                    reading.targetPeak = std::max(reading.targetPeak, std::abs(targetBand));
                    const auto weight = state.reduction * bandContribution * mix;
                    reading.carveWeight = std::max(reading.carveWeight, weight);
                }
            }

            target[channel][sample] = input - mix * delta;
        }

        if constexpr (Metering)
        {
            if (++samplesInWindow >= samplesPerFrame)
            {
                publishMeterFrame(settings);
                window = {};
                window.source = source;
                samplesInWindow = 0;
            }
        }
    }
}

void Engine::setMeteringEnabled(bool enabled) noexcept
{
    meteringEnabled.store(enabled, std::memory_order_relaxed);
}

void Engine::publishMeterFrame(const Settings& settings) noexcept
{
    window.lowCutHz = settings.lowCutHz;
    window.highCutHz = settings.highCutHz;
    window.filterCeilingHz = filterCeiling;
    meterSlots[writeIndex] = window;
    writeIndex = middle.exchange(writeIndex | readyBit, std::memory_order_acq_rel) & indexMask;
}

bool Engine::readMeterFrame(MeterFrame& frame) noexcept
{
    if ((middle.load(std::memory_order_acquire) & readyBit) == 0)
        return false;

    readIndex = middle.exchange(readIndex, std::memory_order_acq_rel) & indexMask;
    frame = meterSlots[readIndex];
    return true;
}
}
