#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>
namespace { constexpr int bands=16; constexpr float pi=3.14159265358979323846f; }
juce::AudioProcessorValueTreeState::ParameterLayout EpsilonCarveAudioProcessor::makeLayout(){
 std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
 auto add=[&](const char* id,const char* name,float lo,float hi,float def){p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{id,1},name,juce::NormalisableRange<float>(lo,hi),def));};
 add("amount","Amount",0,100,40);add("sensitivity","Sensitivity",-48,24,0);add("attack","Attack ms",1,150,15);add("release","Release ms",10,1000,180);add("mix","Mix",0,100,100);add("low","Low cutoff Hz",30,1000,40);add("high","High cutoff Hz",1000,20000,16000);
 p.push_back(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{"external",1},"External sidechain",true));
 return {p.begin(),p.end()};
}
EpsilonCarveAudioProcessor::EpsilonCarveAudioProcessor():AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true).withInput("Sidechain",juce::AudioChannelSet::stereo(),false)),params(*this,nullptr,"PARAMETERS",makeLayout()){}
bool EpsilonCarveAudioProcessor::isBusesLayoutSupported(const BusesLayout& l) const {auto m=l.getMainInputChannelSet();return (m==juce::AudioChannelSet::mono()||m==juce::AudioChannelSet::stereo())&&l.getMainOutputChannelSet()==m&&(l.inputBuses.size()<2||l.getChannelSet(true,1).isDisabled()||l.getChannelSet(true,1)==juce::AudioChannelSet::mono()||l.getChannelSet(true,1)==juce::AudioChannelSet::stereo());}
void EpsilonCarveAudioProcessor::prepareToPlay(double sampleRate,int){sr=sampleRate;for(int c=0;c<2;++c)for(int b=0;b<bands;++b){auto f=60.0f*std::pow(2.0f,b*std::log2(14000.0f/60.0f)/(bands-1));target[c][b]={0,0,0,0,f};detector[c][b]={0,0,0,0,f};}}
void EpsilonCarveAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer,juce::MidiBuffer&){
 juce::ScopedNoDenormals noDenormals;
 const int n=buffer.getNumSamples(), channels=juce::jmin(2,getTotalNumOutputChannels());
 const auto* side=getBusCount(true)>1?getBusBuffer(buffer,true,1).getReadPointer(0):nullptr;
 const int sideChannels=getBusCount(true)>1?getBusBuffer(buffer,true,1).getNumChannels():0;
 const bool useExternal=params.getRawParameterValue("external")->load()>0.5f && sideChannels>0;
 const float amount=params.getRawParameterValue("amount")->load()/100.0f;
 const float sensitivity=std::pow(10.0f,params.getRawParameterValue("sensitivity")->load()/20.0f);
 const float mix=params.getRawParameterValue("mix")->load()/100.0f;
 const float attack=std::exp(-1.0f/(juce::jmax(1.0f,params.getRawParameterValue("attack")->load())*0.001f*float(sr)));
 const float release=std::exp(-1.0f/(juce::jmax(1.0f,params.getRawParameterValue("release")->load())*0.001f*float(sr)));
 const float low=params.getRawParameterValue("low")->load(),high=params.getRawParameterValue("high")->load();
 for(int i=0;i<n;++i){for(int c=0;c<channels;++c){auto* out=buffer.getWritePointer(c);float x=out[i];float sc=x;
 if(useExternal){auto sb=getBusBuffer(buffer,true,1);sc=sb.getReadPointer(juce::jmin(c,sb.getNumChannels()-1))[i];}
 float delta=0;
 for(int b=0;b<bands;++b){auto& d=detector[c][b];auto& t=target[c][b];
 const float f=juce::jmin(t.frequency,float(sr)*0.12f);const float g=2.0f*std::sin(pi*f/float(sr));const float damp=1.0f/1.4f;
 // Chamberlin state-variable bandpass, conservative damping and frequency clamp.
 d.lp+=g*d.bp;float dh=sc-d.lp-damp*d.bp;d.bp+=g*dh;
 t.lp+=g*t.bp;float th=x-t.lp-damp*t.bp;t.bp+=g*th;
 const float level=std::abs(d.bp)*sensitivity;
 d.envelope=(level>d.envelope?attack:release)*d.envelope+(1.0f-(level>d.envelope?attack:release))*level;
 float desired=(t.frequency>=low&&t.frequency<=high)?amount*juce::jlimit(0.0f,0.7f,d.envelope*3.0f):0.0f;
 t.reduction=0.995f*t.reduction+0.005f*desired;
 delta+=t.bp*t.reduction*(1.0f/4.0f);
 }
 out[i]=x-mix*delta;
 }}
}
juce::AudioProcessorEditor* EpsilonCarveAudioProcessor::createEditor(){return new EpsilonCarveAudioProcessorEditor(*this);}
void EpsilonCarveAudioProcessor::getStateInformation(juce::MemoryBlock& dest){auto state=params.copyState();auto xml=state.createXml();copyXmlToBinary(*xml,dest);}
void EpsilonCarveAudioProcessor::setStateInformation(const void* data,int size){auto xml=getXmlFromBinary(data,size);if(xml&&xml->hasTagName(params.state.getType()))params.replaceState(juce::ValueTree::fromXml(*xml));}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new EpsilonCarveAudioProcessor();}
