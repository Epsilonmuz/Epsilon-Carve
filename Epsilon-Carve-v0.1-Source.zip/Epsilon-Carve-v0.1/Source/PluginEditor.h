#pragma once
#include "PluginProcessor.h"
class EpsilonCarveAudioProcessorEditor : public juce::AudioProcessorEditor {
public:
 explicit EpsilonCarveAudioProcessorEditor(EpsilonCarveAudioProcessor&);
 void paint(juce::Graphics&) override;
 void resized() override;
private:
 EpsilonCarveAudioProcessor& processor;
 using Attachment=juce::AudioProcessorValueTreeState::SliderAttachment;
 std::array<juce::Slider,7> knobs;
 std::array<juce::Label,7> labels;
 std::array<std::unique_ptr<Attachment>,7> attachments;
 juce::ToggleButton external{"External sidechain"};
 std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> externalAttachment;
 JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(EpsilonCarveAudioProcessorEditor)
};
