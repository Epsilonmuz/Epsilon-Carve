# Epsilon Carve — experimental JUCE sidechain processor

![Illustrated interface concept](docs/UI_CONCEPT.png)

**Status: source prototype only. Not compiled, measured, or FL Studio-validated.** The image above is a visual target, **not a screenshot** of this version. The present UI is a simple native JUCE editor.

## Controls (v0.1)

| Control | What it does | Starting point |
|---|---|---|
| Amount | Depth of dynamic frequency subtraction | 20–40% |
| Sensitivity | Gain applied to the detector signal | 0 dB |
| Attack | How quickly detector follows rising energy | 10–20 ms |
| Release | How quickly detector returns after energy falls | 150–250 ms |
| Mix | Dry/processed blend | 100% |
| Low cut | Lower boundary of ducking | 100 Hz for vocal space |
| High cut | Upper boundary of ducking | 8 kHz for vocal space |
| External sidechain | Use host's sidechain bus if available; otherwise falls back to self detection | On |

## Signal-flow diagram

`Sidechain (vocal) → 16 frequency detectors → envelope followers → reduction control`

`Target (instrumental) → 16 frequency filters → subtract controlled bands → output`

## FL Studio setup (requires host verification)

1. Build and install the VST3, then scan it in FL Studio.
2. Put Epsilon Carve on the **target** track (for example, instrumental bus).
3. Route the **source** track (for example, vocal) to the target as a sidechain-only send.
4. In the wrapper's processing settings, map the incoming sidechain to the plugin's secondary input bus. FL Studio routing and bus exposure must be verified with the built VST3.
5. Start Amount 25%, Sensitivity 0 dB, Attack 15 ms, Release 180 ms. Adjust by ear and compare bypass at matched loudness.

## Build on macOS

Install JUCE in a sibling directory or clone it into `JUCE`:

```bash
git clone --depth 1 https://github.com/juce-framework/JUCE.git JUCE
cmake -S . -B build -G Xcode
cmake --build build --config Release
```

The generated `.vst3` is under the build products; copy it to `~/Library/Audio/Plug-Ins/VST3/`, then rescan in FL Studio.

## Important limitations

- This is an **original exploratory implementation**, not the proprietary Trackspacer algorithm.
- 16 simplified frequency bands; not a calibrated 32-band dynamic EQ.
- No frequency analyzer, freeze, mid/side, advanced stereo linking, oversampling, latency characterization, or preset bank yet.
- Current Chamberlin filters are a prototype; high-frequency response, stability, spectral coloration, gain staging, and real-time performance need dedicated testing before production use.
- The prototype is not a verified drop-in replacement for Trackspacer.

## Next validation gates

Compile with JUCE, test mono/stereo/external bus configurations, process silence/impulses/sines/noise at 44.1 and 48 kHz, verify finite output and no clipping, capture automation/state recall, and test sidechain routing in FL Studio. Benchmark against actual Trackspacer renders before making similarity claims.
