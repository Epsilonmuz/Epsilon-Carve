/*

    IMPORTANT! This file is auto-generated each time you save your
    project - if you alter its contents, your changes may be overwritten!

*/

#include <juce_graphics/juce_graphics_libwebp_dsp_dec_sse41.c>
