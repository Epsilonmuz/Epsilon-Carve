#pragma once

#include <array>
#include <atomic>
#include <cstddef>

namespace carve
{
constexpr std::size_t bandCount = 32;
constexpr std::size_t maxChannels = 2;
constexpr float lowestBandHz = 20.0f;
constexpr float highestBandHz = 20000.0f;

float frequencyAt(float position) noexcept;
float frequencyPosition(float frequencyHz) noexcept;
float bandCentreHz(std::size_t index) noexcept;

enum class TriggerSource
{
    external,
    self,
    unavailable
};

struct Settings
{
    float amountPercent;
    float sensitivityDb;
    float attackMs;
    float releaseMs;
    float mixPercent;
    float lowCutHz;
    float highCutHz;
    bool external;
};

struct BandReading
{
    float triggerPeak = 0.0f;
    float cutWeight = 0.0f;
    float warpedCentre = 0.0f;
};

struct MeterFrame
{
    std::array<BandReading, bandCount> bands {};
    float sampleRate = 44100.0f;
    float triggerInputPeak = 0.0f;
    float lowCutHz = lowestBandHz;
    float highCutHz = highestBandHz;
    float mix = 1.0f;
    TriggerSource source = TriggerSource::self;
};

// Evaluates the frozen complex response, including all overlapping bands and Mix.
// This is for the display or tests and runs outside the audio callback.
float cutResponseDb(const MeterFrame& frame, float frequencyHz) noexcept;

class Engine
{
public:
    using TargetChannels = std::array<float*, maxChannels>;
    using TriggerChannels = std::array<const float*, maxChannels>;

    void prepare(double sampleRateHz) noexcept;
    void process(const TargetChannels& target, int numTargetChannels,
                 const TriggerChannels& sidechain, int numSidechainChannels,
                 int samples, const Settings& settings) noexcept;

    // One audio producer and one editor consumer. The audio thread never waits.
    void setMeteringEnabled(bool enabled) noexcept;
    bool readMeterFrame(MeterFrame& frame) noexcept;

private:
    struct Coefficients
    {
        float a1 = 1.0f, a2 = 0.0f, a3 = 0.0f, damping = 1.0f;
    };

    struct Filter
    {
        float integrator1 = 0.0f, integrator2 = 0.0f;
        float bandpass(float input, const Coefficients& coefficients) noexcept;
    };

    struct Band
    {
        Coefficients detector, equalizer;
        float warpedCentre = 0.0f;
        std::array<Filter, maxChannels> detectorState {}, eqState {};
        float envelope = 0.0f, cutWeight = 0.0f;
    };

    template <bool Metering>
    void processSamples(const TargetChannels& target, int targetChannels,
                        const TriggerChannels& trigger, int triggerChannels, int samples,
                        const Settings& settings) noexcept;
    void publishMeterFrame(const Settings& settings) noexcept;

    std::array<Band, bandCount> bands {};
    std::size_t activeBands = 0;
    float sampleRate = 44100.0f;
    float cutSmoothing = 0.0f;

    MeterFrame window;
    int samplesInWindow = 0;
    int samplesPerFrame = 1470;
    std::atomic<bool> meteringEnabled { false };

    // Each side owns one slot. The middle slot carries the most recent publication.
    static constexpr unsigned indexMask = 3;
    static constexpr unsigned readyBit = 4;
    static_assert(std::atomic<unsigned>::is_always_lock_free);
    static_assert(std::atomic<bool>::is_always_lock_free);
    std::array<MeterFrame, 3> meterSlots {};
    unsigned writeIndex = 0;
    unsigned readIndex = 2;
    std::atomic<unsigned> middle { 1 };
};
}
