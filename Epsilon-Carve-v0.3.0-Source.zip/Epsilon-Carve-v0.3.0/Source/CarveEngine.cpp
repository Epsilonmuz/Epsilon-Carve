#include "CarveEngine.h"

#include <algorithm>
#include <cmath>
#include <complex>

namespace carve
{
namespace
{
constexpr double pi = 3.14159265358979323846;
constexpr float detectorDamping = 1.0f / 3.5f;
constexpr float eqDamping = 1.0f / 4.4f;
constexpr float detectorScale = 5.0f;
constexpr float maxCutWeight = 0.74881136f; // 12 dB at the center of a single fully driven section
constexpr float meterFramesPerSecond = 30.0f;
constexpr float bandIndexSpan = static_cast<float>(bandCount - 1);
}

float frequencyAt(float position) noexcept
{
    return lowestBandHz * std::pow(highestBandHz / lowestBandHz, std::clamp(position, 0.0f, 1.0f));
}

float frequencyPosition(float frequencyHz) noexcept
{
    const auto frequency = std::clamp(frequencyHz, lowestBandHz, highestBandHz);
    return std::log(frequency / lowestBandHz) / std::log(highestBandHz / lowestBandHz);
}

float bandCentreHz(std::size_t index) noexcept
{
    return frequencyAt(static_cast<float>(index) / bandIndexSpan);
}

float Engine::Filter::bandpass(float input, const Coefficients& c) noexcept
{
    // Trapezoidal SVF with fixed poles and unity bandpass gain at the center.
    const auto v3 = input - integrator2;
    const auto v1 = c.a1 * integrator1 + c.a2 * v3;
    const auto v2 = integrator2 + c.a2 * integrator1 + c.a3 * v3;
    integrator1 = 2.0f * v1 - integrator1;
    integrator2 = 2.0f * v2 - integrator2;
    return c.damping * v1;
}

void Engine::prepare(double sampleRateHz) noexcept
{
    sampleRate = std::isfinite(sampleRateHz) && sampleRateHz > 0.0
                   ? static_cast<float>(sampleRateHz) : 44100.0f;
    samplesPerFrame = std::max(1, static_cast<int>(std::lround(sampleRate / meterFramesPerSecond)));
    cutSmoothing = 1.0f - std::exp(-1.0f / (sampleRate * 0.004f));
    bands = {};
    window = {};
    samplesInWindow = 0;
    activeBands = 0;

    // At low host sample rates, leave above-bandwidth slots inactive instead of
    // moving several sections to the same frequency.
    for (std::size_t index = 0; index < bandCount; ++index)
    {
        const auto centre = bandCentreHz(index);
        if (centre > sampleRate * 0.475f)
            break;

        auto& band = bands[index];
        const auto g = static_cast<float>(std::tan(pi * centre / sampleRate));
        band.warpedCentre = g;
        const auto coefficients = [g](float damping)
        {
            const auto a1 = 1.0f / (1.0f + g * (g + damping));
            const auto a2 = g * a1;
            return Coefficients { a1, a2, g * a2, damping };
        };
        band.detector = coefficients(detectorDamping);
        band.equalizer = coefficients(eqDamping);
        ++activeBands;
    }
}

void Engine::process(const TargetChannels& target, int numTargetChannels,
                     const TriggerChannels& sidechain, int numSidechainChannels,
                     int samples, const Settings& settings) noexcept
{
    if (numTargetChannels == 0 || samples == 0)
        return;

    const auto useAux = settings.external && numSidechainChannels > 0;
    const auto source = useAux ? TriggerSource::external
                               : settings.external ? TriggerSource::unavailable : TriggerSource::self;
    const TriggerChannels trigger = useAux ? sidechain : TriggerChannels { target[0], target[1] };
    const auto triggerChannels = useAux ? numSidechainChannels : numTargetChannels;

    if (meteringEnabled.load(std::memory_order_relaxed))
    {
        if (window.source != source)
        {
            window = {};
            samplesInWindow = 0;
            window.source = source;
        }
        processSamples<true>(target, numTargetChannels, trigger, triggerChannels, samples, settings);
    }
    else
    {
        if (samplesInWindow != 0)
        {
            window = {};
            samplesInWindow = 0;
        }
        processSamples<false>(target, numTargetChannels, trigger, triggerChannels, samples, settings);
    }
}

template <bool Metering>
void Engine::processSamples(const TargetChannels& target, int targetChannels,
                            const TriggerChannels& trigger, int triggerChannels, int samples,
                            const Settings& settings) noexcept
{
    const auto amount = std::clamp(settings.amountPercent * 0.01f, 0.0f, 1.0f) * maxCutWeight;
    const auto sensitivity = std::pow(10.0f, settings.sensitivityDb / 20.0f) * detectorScale;
    const auto mix = std::clamp(settings.mixPercent * 0.01f, 0.0f, 1.0f);
    const auto timing = [this](float milliseconds)
    {
        return 1.0f - std::exp(-1.0f / (std::max(1.0f, milliseconds) * 0.001f * sampleRate));
    };
    const auto attack = timing(settings.attackMs);
    const auto release = timing(settings.releaseMs);
    const auto low = frequencyPosition(settings.lowCutHz);
    const auto high = frequencyPosition(settings.highCutHz);

    // Each control band covers a log-frequency cell. Fractional overlap makes the
    // cutoffs continuous and lets two cutoffs isolate part of a cell.
    std::array<float, bandCount> rangeAmount {};
    for (std::size_t index = 0; index < activeBands; ++index)
    {
        const auto left = std::max(0.0f, (static_cast<float>(index) - 0.5f) / bandIndexSpan);
        const auto right = std::min(1.0f, (static_cast<float>(index) + 0.5f) / bandIndexSpan);
        const auto overlap = std::clamp((std::min(high, right) - std::max(low, left))
                                            / (right - left), 0.0f, 1.0f);
        rangeAmount[index] = amount * overlap;
    }

    const auto stereoTarget = targetChannels > 1;
    const auto stereoTrigger = triggerChannels > 1;
    for (int sample = 0; sample < samples; ++sample)
    {
        const auto inputL = target[0][sample];
        const auto inputR = stereoTarget ? target[1][sample] : 0.0f;
        const auto keyL = trigger[0][sample];
        const auto keyR = stereoTrigger ? trigger[1][sample] : 0.0f;
        auto wetL = inputL;
        auto wetR = inputR;

        if constexpr (Metering)
        {
            const auto peak = std::max(std::abs(keyL), std::abs(keyR));
            window.triggerInputPeak = std::max(window.triggerInputPeak, peak);
        }

        for (std::size_t index = 0; index < activeBands; ++index)
        {
            auto& band = bands[index];
            auto level = std::abs(band.detectorState[0].bandpass(keyL, band.detector));
            if (stereoTrigger)
                level = std::max(level, std::abs(band.detectorState[1].bandpass(keyR, band.detector)));

            const auto step = level > band.envelope ? attack : release;
            band.envelope += step * (level - band.envelope);
            const auto desired = rangeAmount[index] * std::min(1.0f, band.envelope * sensitivity);
            band.cutWeight += cutSmoothing * (desired - band.cutWeight);
            if (desired == 0.0f && band.cutWeight < 1.0e-7f)
                band.cutWeight = 0.0f;

            wetL -= band.cutWeight * band.eqState[0].bandpass(wetL, band.equalizer);
            if (stereoTarget)
                wetR -= band.cutWeight * band.eqState[1].bandpass(wetR, band.equalizer);

            if constexpr (Metering)
                window.bands[index].triggerPeak = std::max(window.bands[index].triggerPeak, level);
        }

        target[0][sample] = inputL + mix * (wetL - inputL);
        if (stereoTarget)
            target[1][sample] = inputR + mix * (wetR - inputR);

        if constexpr (Metering)
        {
            if (++samplesInWindow >= samplesPerFrame)
            {
                publishMeterFrame(settings);
                const auto source = window.source;
                window = {};
                window.source = source;
                samplesInWindow = 0;
            }
        }
    }
}

float cutResponseDb(const MeterFrame& frame, float frequencyHz) noexcept
{
    if (frequencyHz <= 0.0f || frequencyHz >= frame.sampleRate * 0.5f || frame.mix <= 0.0f)
        return 0.0f;

    const auto warped = std::tan(pi * frequencyHz / frame.sampleRate);
    std::complex<double> wet { 1.0, 0.0 };
    for (const auto& band : frame.bands)
    {
        if (band.warpedCentre <= 0.0f || band.cutWeight <= 0.0f)
            continue;

        const auto ratio = warped / band.warpedCentre;
        const auto dampingTerm = eqDamping * ratio;
        const std::complex<double> numerator { 0.0, dampingTerm };
        const std::complex<double> denominator { 1.0 - ratio * ratio, dampingTerm };
        wet *= 1.0 - static_cast<double>(band.cutWeight) * numerator / denominator;
    }

    const auto mix = static_cast<double>(frame.mix);
    const auto magnitude = std::abs(1.0 - mix + mix * wet);
    return static_cast<float>(20.0 * std::log10(std::clamp(magnitude, 1.0e-6, 1.0)));
}

void Engine::setMeteringEnabled(bool enabled) noexcept
{
    meteringEnabled.store(enabled, std::memory_order_relaxed);
}

void Engine::publishMeterFrame(const Settings& settings) noexcept
{
    window.sampleRate = sampleRate;
    window.lowCutHz = settings.lowCutHz;
    window.highCutHz = settings.highCutHz;
    window.mix = std::clamp(settings.mixPercent * 0.01f, 0.0f, 1.0f);
    for (std::size_t index = 0; index < activeBands; ++index)
    {
        window.bands[index].cutWeight = bands[index].cutWeight;
        window.bands[index].warpedCentre = bands[index].warpedCentre;
    }
    meterSlots[writeIndex] = window;
    writeIndex = middle.exchange(writeIndex | readyBit, std::memory_order_acq_rel) & indexMask;
}

bool Engine::readMeterFrame(MeterFrame& frame) noexcept
{
    if ((middle.load(std::memory_order_acquire) & readyBit) == 0)
        return false;

    readIndex = middle.exchange(readIndex, std::memory_order_acq_rel) & indexMask;
    frame = meterSlots[readIndex];
    return true;
}
}
