#include "PluginEditor.h"

#include <cmath>

namespace
{
const juce::Colour background { 0xff0e1621 };
const juce::Colour panel { 0xff182534 };
const juce::Colour plotBackground { 0xff101a27 };
const juce::Colour textColour { 0xffedf5ff };
const juce::Colour muted { 0xffa5b6c8 };
const juce::Colour blue { 0xff40caff };
constexpr float floorDb = -80.0f;
constexpr float cutFloorDb = -24.0f;
constexpr auto centreKnob = 1u;

juce::Font font(float height, bool bold = false)
{
    return juce::Font(juce::FontOptions(height, bold ? juce::Font::bold : juce::Font::plain));
}

juce::String frequencyText(float frequency, int decimals)
{
    return frequency < 1000.0f ? juce::String(frequency, 0) + " Hz"
                               : juce::String(frequency * 0.001f, decimals) + " kHz";
}

struct PlotBounds
{
    juce::Rectangle<float> signal;
    juce::Rectangle<float> cut;

    float x(float position) const { return signal.getX() + signal.getWidth() * position; }
    float ySignal(float db) const
    {
        return signal.getY() + signal.getHeight() * juce::jlimit(0.0f, 1.0f, db / floorDb);
    }
    float yCut(float db) const
    {
        return cut.getY() + cut.getHeight() * juce::jlimit(0.0f, 1.0f, db / cutFloorDb);
    }
};
}

class CarveKnobTheme final : public juce::LookAndFeel_V4
{
public:
    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float value, float start, float end, juce::Slider& slider) override
    {
        const auto radius = static_cast<float>(juce::jmin(width, height)) * 0.5f - 7.0f;
        if (radius <= 0.0f)
            return;

        const auto centre = juce::Point<float>(static_cast<float>(x) + 0.5f * static_cast<float>(width),
                                              static_cast<float>(y) + 0.5f * static_cast<float>(height));
        const auto accent = slider.findColour(juce::Slider::rotarySliderFillColourId);
        const auto angle = start + value * (end - start);

        juce::Path rail, active;
        rail.addCentredArc(centre.x, centre.y, radius, radius, 0.0f, start, end, true);
        active.addCentredArc(centre.x, centre.y, radius, radius, 0.0f, start, angle, true);
        const juce::PathStrokeType stroke(radius > 45.0f ? 4.0f : 3.0f,
                                          juce::PathStrokeType::curved, juce::PathStrokeType::rounded);
        g.setColour(panel.brighter(0.30f));
        g.strokePath(rail, stroke);
        g.setColour(accent);
        g.strokePath(active, stroke);

        const auto face = juce::Rectangle<float>(2.0f * radius - 13.0f, 2.0f * radius - 13.0f)
                                  .withCentre(centre);
        g.setGradientFill(juce::ColourGradient(panel.brighter(0.12f), face.getTopLeft(),
                                               plotBackground, face.getBottomLeft(), false));
        g.fillEllipse(face);
        g.setColour(panel.brighter(0.28f));
        g.drawEllipse(face, 1.0f);
        g.setColour(textColour);
        g.drawLine(juce::Line<float>(centre.getPointOnCircumference(radius * 0.38f, angle),
                                      centre.getPointOnCircumference(radius * 0.73f, angle)), 2.0f);
    }
};

class CarveBandDisplay final : public juce::Component, private juce::Timer
{
public:
    explicit CarveBandDisplay(EpsilonCarveAudioProcessor& audioProcessor)
        : processor(audioProcessor),
          low(*processor.params.getRawParameterValue("low")),
          high(*processor.params.getRawParameterValue("high"))
    {
        setTitle("Sidechain spectrum and applied gain reduction");
        processor.readMeterFrame(frame);
        processor.setMeteringEnabled(true);
        startTimerHz(30);
    }

    ~CarveBandDisplay() override
    {
        stopTimer();
        processor.setMeteringEnabled(false);
    }

    void paint(juce::Graphics& g) override
    {
        g.setColour(panel);
        g.fillRoundedRectangle(getLocalBounds().toFloat(), 12.0f);
        if (getWidth() < 270 || getHeight() < 150)
            return;

        const auto plot = plotBounds();
        paintHeader(g);
        paintGrid(g, plot);
        if (hasFrame)
            paintTraces(g, plot);

        if (hoverPosition >= 0.0f)
        {
            g.setColour(muted.withAlpha(0.65f));
            g.drawVerticalLine(juce::roundToInt(plot.x(hoverPosition)), plot.signal.getY(), plot.cut.getBottom());
        }
        paintReadout(g);
    }

    void mouseMove(const juce::MouseEvent& event) override
    {
        const auto plot = plotBounds();
        const auto region = plot.signal.getUnion(plot.cut);
        hoverPosition = region.contains(event.position)
                        ? (event.position.x - region.getX()) / region.getWidth() : -1.0f;
        repaint();
    }

    void mouseExit(const juce::MouseEvent&) override
    {
        hoverPosition = -1.0f;
        repaint();
    }

private:
    PlotBounds plotBounds() const
    {
        const auto width = static_cast<float>(getWidth()) - 76.0f;
        const auto available = static_cast<float>(getHeight()) - 126.0f;
        const auto signalHeight = available * 0.56f;
        return { { 55.0f, 54.0f, width, signalHeight },
                 { 55.0f, 71.0f + signalHeight, width, available - signalHeight } };
    }

    void timerCallback() override
    {
        const auto now = juce::Time::getMillisecondCounter();
        bool redraw = false;
        if (processor.readMeterFrame(frame))
        {
            hasFrame = true;
            lastFrameMs = now;
            redraw = true;
        }
        else if (hasFrame && now - lastFrameMs > 250)
        {
            hasFrame = false;
            redraw = true;
        }

        const auto lo = low.load(std::memory_order_relaxed);
        const auto hi = high.load(std::memory_order_relaxed);
        if (lo != displayedLow || hi != displayedHigh)
        {
            displayedLow = lo;
            displayedHigh = hi;
            redraw = true;
        }

        if (redraw)
            repaint();
    }

    juce::String sourceStatus() const
    {
        if (!hasFrame)
            return "WAITING FOR AUDIO";
        if (frame.source == carve::TriggerSource::self)
            return "SELF DETECTION";
        if (frame.source == carve::TriggerSource::unavailable)
            return "EXT INPUT DISABLED / SELF";
        return frame.triggerInputPeak >= 0.0001f ? "EXT / SIGNAL" : "EXT / QUIET";
    }

    void paintHeader(juce::Graphics& g) const
    {
        g.setColour(textColour);
        g.setFont(font(15.0f, true));
        g.drawText("SIDECHAIN SPECTRUM", 16, 7, 227, 21, juce::Justification::centredLeft);

        const auto badge = juce::Rectangle<float>(static_cast<float>(getWidth()) - 204.0f,
                                                  9.0f, 186.0f, 20.0f);
        g.setColour(plotBackground);
        g.fillRoundedRectangle(badge, 4.0f);
        g.setColour(hasFrame && frame.source == carve::TriggerSource::external
                             && frame.triggerInputPeak >= 0.0001f ? blue : muted);
        g.setFont(font(10.0f, true));
        g.drawFittedText(sourceStatus(), badge.toNearestInt(), juce::Justification::centred, 1);

        g.setColour(blue);
        g.fillEllipse(16.0f, 36.0f, 6.0f, 6.0f);
        g.drawText("SIDECHAIN", 27, 31, 83, 15, juce::Justification::centredLeft);
        g.setColour(textColour);
        g.fillEllipse(118.0f, 36.0f, 6.0f, 6.0f);
        g.drawText("APPLIED CUT", 129, 31, 109, 15, juce::Justification::centredLeft);
    }

    void paintGrid(juce::Graphics& g, const PlotBounds& plot) const
    {
        g.setColour(plotBackground);
        g.fillRect(plot.signal);
        g.fillRect(plot.cut);

        const auto range = plot.signal.getUnion(plot.cut);
        const auto left = plot.x(carve::frequencyPosition(displayedLow));
        const auto right = plot.x(carve::frequencyPosition(displayedHigh));
        g.setColour(juce::Colours::black.withAlpha(0.26f));
        if (left < right)
        {
            g.fillRect(range.withRight(left));
            g.fillRect(range.withLeft(right));
            g.setColour(blue.withAlpha(0.53f));
            if (left > range.getX())
                g.drawVerticalLine(juce::roundToInt(left), range.getY(), range.getBottom());
            if (right < range.getRight())
                g.drawVerticalLine(juce::roundToInt(right), range.getY(), range.getBottom());
        }
        else
        {
            g.fillRect(range);
        }

        g.setFont(font(10.0f));
        const auto horizontal = [&g, &plot](float y, const juce::String& label)
        {
            g.setColour(muted.withAlpha(0.21f));
            g.drawHorizontalLine(juce::roundToInt(y), plot.signal.getX(), plot.signal.getRight());
            g.setColour(muted);
            g.drawText(label, 5, juce::roundToInt(y) - 7, 44, 14, juce::Justification::centredRight);
        };

        horizontal(plot.ySignal(0.0f), "0 dBFS");
        for (int db = -20; db >= -80; db -= 20)
            horizontal(plot.ySignal(static_cast<float>(db)), juce::String(db));
        horizontal(plot.yCut(0.0f), "0 dB");
        for (int db = -6; db >= -24; db -= 6)
            horizontal(plot.yCut(static_cast<float>(db)), juce::String(db));

        constexpr std::array<float, 10> marks { 20.0f, 50.0f, 100.0f, 200.0f, 500.0f,
                                              1000.0f, 2000.0f, 5000.0f, 10000.0f, 20000.0f };
        for (const auto frequency : marks)
        {
            const auto x = juce::roundToInt(plot.x(carve::frequencyPosition(frequency)));
            g.setColour(muted.withAlpha(0.12f));
            g.drawVerticalLine(x, plot.signal.getY(), plot.signal.getBottom());
            g.drawVerticalLine(x, plot.cut.getY(), plot.cut.getBottom());
            g.setColour(muted);
            g.drawText(frequencyText(frequency, 0), x - 25,
                       juce::roundToInt(plot.cut.getBottom()) + 3, 50, 15,
                       juce::Justification::centred);
        }
    }

    float triggerDb(float position) const
    {
        const auto index = juce::jlimit(0.0f, 1.0f, position) * static_cast<float>(carve::bandCount - 1);
        const auto from = static_cast<std::size_t>(index);
        const auto to = juce::jmin(from + 1, carve::bandCount - 1);
        const auto a = juce::Decibels::gainToDecibels(frame.bands[from].triggerPeak, floorDb);
        const auto b = juce::Decibels::gainToDecibels(frame.bands[to].triggerPeak, floorDb);
        return a + (b - a) * (index - static_cast<float>(from));
    }

    void paintTraces(juce::Graphics& g, const PlotBounds& plot) const
    {
        juce::Path key, reduction;
        constexpr int tracePoints = 180;
        for (int index = 0; index < tracePoints; ++index)
        {
            const auto position = static_cast<float>(index) / static_cast<float>(tracePoints - 1);
            const auto x = plot.x(position);
            const auto keyY = plot.ySignal(triggerDb(position));
            const auto cutY = plot.yCut(carve::cutResponseDb(frame, carve::frequencyAt(position)));
            if (index == 0)
            {
                key.startNewSubPath(x, keyY);
                reduction.startNewSubPath(x, cutY);
            }
            else
            {
                key.lineTo(x, keyY);
                reduction.lineTo(x, cutY);
            }
        }

        auto fill = key;
        fill.lineTo(plot.signal.getRight(), plot.signal.getBottom());
        fill.lineTo(plot.signal.getX(), plot.signal.getBottom());
        fill.closeSubPath();
        g.setGradientFill(juce::ColourGradient(blue.withAlpha(0.26f), 0.0f, plot.signal.getY(),
                                               blue.withAlpha(0.01f), 0.0f, plot.signal.getBottom(), false));
        g.fillPath(fill);
        g.setColour(blue);
        g.strokePath(key, juce::PathStrokeType(1.7f));
        g.setColour(textColour);
        g.strokePath(reduction, juce::PathStrokeType(1.6f));
    }

    void paintReadout(juce::Graphics& g) const
    {
        juce::String message = "Hover to compare the sidechain level and applied cut at a frequency.";
        if (displayedLow >= displayedHigh)
        {
            message = "LOW CUT >= HIGH CUT  /  NO ACTIVE RANGE";
        }
        else if (hasFrame && hoverPosition >= 0.0f)
        {
            const auto frequency = carve::frequencyAt(hoverPosition);
            message = frequencyText(frequency, 2)
                + "   |   Sidechain " + juce::String(triggerDb(hoverPosition), 1) + " dBFS"
                + "   |   Applied cut " + juce::String(carve::cutResponseDb(frame, frequency), 2) + " dB";
        }
        g.setColour(muted);
        g.setFont(font(11.0f));
        g.drawFittedText(message, 16, getHeight() - 27, getWidth() - 32, 18,
                         juce::Justification::centredLeft, 1);
    }

    EpsilonCarveAudioProcessor& processor;
    const std::atomic<float>& low;
    const std::atomic<float>& high;
    carve::MeterFrame frame;
    float displayedLow = carve::lowestBandHz;
    float displayedHigh = carve::highestBandHz;
    float hoverPosition = -1.0f;
    bool hasFrame = false;
    juce::uint32 lastFrameMs = 0;
};

EpsilonCarveAudioProcessorEditor::EpsilonCarveAudioProcessorEditor(EpsilonCarveAudioProcessor& processor)
    : AudioProcessorEditor(&processor),
      knobTheme(std::make_unique<CarveKnobTheme>()),
      display(std::make_unique<CarveBandDisplay>(processor))
{
    constexpr std::array<const char*, 3> ids { "low", "amount", "high" };
    constexpr std::array<const char*, 3> names { "LOW CUT", "AMOUNT", "HIGH CUT" };
    constexpr std::array<double, 3> initial { carve::lowestBandHz, 25.0, carve::highestBandHz };

    addAndMakeVisible(*display);
    for (std::size_t index = 0; index < knobs.size(); ++index)
    {
        auto& knob = knobs[index];
        knob.setLookAndFeel(knobTheme.get());
        knob.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        knob.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 100, 23);
        knob.setScrollWheelEnabled(false);
        knob.setDoubleClickReturnValue(true, initial[index]);
        knob.setColour(juce::Slider::rotarySliderFillColourId, index == centreKnob ? blue : muted);
        knob.setColour(juce::Slider::textBoxTextColourId, textColour);
        knob.setColour(juce::Slider::textBoxBackgroundColourId, plotBackground);
        knob.setColour(juce::Slider::textBoxOutlineColourId, panel.brighter(0.18f));
        knob.setTitle(names[index]);
        if (index == centreKnob)
            knob.setTextValueSuffix("%");
        addAndMakeVisible(knob);

        auto& label = labels[index];
        label.setText(names[index], juce::dontSendNotification);
        label.setFont(font(index == centreKnob ? 14.0f : 11.0f, true));
        label.setJustificationType(juce::Justification::centred);
        label.setColour(juce::Label::textColourId, index == centreKnob ? textColour : muted);
        addAndMakeVisible(label);
        attachments[index] = std::make_unique<Attachment>(processor.params, ids[index], knob);
    }

    setResizable(true, true);
    setResizeLimits(640, 510, 1120, 800);
    setSize(760, 566);
}

EpsilonCarveAudioProcessorEditor::~EpsilonCarveAudioProcessorEditor() = default;

void EpsilonCarveAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(background);
    g.setColour(blue);
    g.setFont(font(25.0f, true));
    g.drawText("EPSILON CARVE", 22, 12, getWidth() - 153, 29, juce::Justification::centredLeft);
    g.setColour(muted);
    g.setFont(font(12.0f));
    g.drawText("Dynamic sidechain EQ", 23, 43, 297, 18, juce::Justification::centredLeft);
    g.drawText("V0.3.0", getWidth() - 112, 18, 90, 20, juce::Justification::centredRight);
}

void EpsilonCarveAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced(22, 13);
    area.removeFromTop(56);
    const auto controls = area.removeFromBottom(164);
    display->setBounds(area.withTrimmedBottom(14));

    for (std::size_t index = 0; index < knobs.size(); ++index)
    {
        const auto centreX = controls.getX() + controls.getWidth() * static_cast<int>(index + 1) / 4;
        const auto width = index == centreKnob ? 142 : 106;
        auto cell = juce::Rectangle<int>(centreX - width / 2, controls.getY(), width, controls.getHeight());
        if (index != centreKnob)
            cell.removeFromTop(29);
        labels[index].setBounds(cell.removeFromBottom(22));
        knobs[index].setBounds(cell);
    }
}
