#pragma once

#include "PluginProcessor.h"

class CarveBandDisplay;
class CarveKnobTheme;

class EpsilonCarveAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit EpsilonCarveAudioProcessorEditor(EpsilonCarveAudioProcessor&);
    ~EpsilonCarveAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    using Attachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    std::unique_ptr<CarveKnobTheme> knobTheme;
    std::array<juce::Slider, 3> knobs;
    std::array<juce::Label, 3> labels;
    std::array<std::unique_ptr<Attachment>, 3> attachments;
    std::unique_ptr<CarveBandDisplay> display;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(EpsilonCarveAudioProcessorEditor)
};
