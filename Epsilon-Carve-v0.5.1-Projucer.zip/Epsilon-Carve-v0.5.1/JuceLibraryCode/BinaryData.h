/* =========================================================================================

   This is an auto-generated file: Any edits you make may be overwritten!

*/

#pragma once

namespace BinaryData
{
    extern const char*   BarlowSemiCondensedMedium_ttf;
    const int            BarlowSemiCondensedMedium_ttfSize = 163992;

    extern const char*   BarlowSemiCondensedSemiBold_ttf;
    const int            BarlowSemiCondensedSemiBold_ttfSize = 168500;

    extern const char*   BarlowSemiCondensedBold_ttf;
    const int            BarlowSemiCondensedBold_ttfSize = 170604;

    // Number of elements in the namedResourceList and originalFileNames arrays.
    const int namedResourceListSize = 3;

    // Points to the start of a list of resource names.
    extern const char* namedResourceList[];

    // Points to the start of a list of resource filenames.
    extern const char* originalFilenames[];

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding data and its size (or a null pointer if the name isn't found).
    const char* getNamedResource (const char* resourceNameUTF8, int& dataSizeInBytes);

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding original, non-mangled filename (or a null pointer if the name isn't found).
    const char* getNamedResourceOriginalFilename (const char* resourceNameUTF8);
}
